def msg1():  
    print("This is msg1")
